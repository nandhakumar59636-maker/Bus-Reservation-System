# Bus Reservation System

A clean, console-based **Bus Reservation System** built with pure Java and solid Object-Oriented design.

This project demonstrates end-to-end feature ownership: searching buses, viewing seat maps, booking tickets with proper validation, cancelling bookings, and managing state correctly.

---

## Features

- Search buses by source and destination
- View real-time seat map (available / booked)
- Book a seat with full validation
- Cancel a booking by Booking ID
- View all current bookings
- Proper edge-case handling (already booked seats, invalid seat numbers, empty name, etc.)

---

## Tech Stack

- **Language:** Java 17+
- **Concepts used:** OOP (Encapsulation, Abstraction), Collections, Exception Handling, Optional, Streams
- **No external libraries** – pure Java

---

## Project Structure

```
bus-reservation-system/
├── src/main/java/com/busreservation/
│   ├── Main.java                  # Application entry point & menu
│   ├── model/
│   │   ├── Bus.java               # Bus entity + seat management
│   │   ├── Seat.java              # Individual seat
│   │   └── Booking.java           # Confirmed booking record
│   └── service/
│       ├── BusService.java        # Search & seat map logic
│       └── BookingService.java    # Booking & cancellation logic
└── README.md
```

---

## How to Run

### Option 1: Compile & Run from terminal

```bash
# Navigate to project root
cd bus-reservation-system

# Compile all Java files
javac -d out src/main/java/com/busreservation/**/*.java src/main/java/com/busreservation/*.java

# Run the application
java -cp out com.busreservation.Main
```

### Option 2: Using any IDE
1. Open the project in IntelliJ IDEA / Eclipse / VS Code
2. Run `Main.java`

---

## Sample Flow

```
1. Search Buses → Enter "Chennai" and "Madurai"
2. View Seat Map → Enter bus number (e.g. TN01A1234)
3. Book Ticket → Choose seat, enter name
4. View All Bookings → See your confirmed booking with ID
5. Cancel Ticket → Enter Booking ID to free the seat
```

---

## Design Decisions & Edge Cases Handled

| Scenario                        | How it is handled                          |
|--------------------------------|--------------------------------------------|
| Seat already booked            | Throws clear error, booking rejected       |
| Invalid seat number            | Validation before any state change         |
| Empty passenger name           | Rejected with message                      |
| Bus number not found           | Clear error message                        |
| Cancel non-existent booking    | Returns false + user-friendly message      |
| Concurrent-like seat booking   | Seat state is checked before booking       |

---

## What I learned / would improve next

- Always validate inputs and edge cases **before** changing state
- Keep business logic in service classes (separation of concerns)
- Provide clear feedback to the user for every action
- Next improvements: add persistence (file/DB), multi-threading safety, and a simple GUI or REST API layer

---

## Author

**K. Nandha Kumar**  
Java Developer | Full-Stack Enthusiast  
Email: nandhakumar5963@gmail.com
