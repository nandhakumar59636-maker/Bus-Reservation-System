package com.busreservation;

import com.busreservation.model.Booking;
import com.busreservation.model.Bus;
import com.busreservation.service.BookingService;
import com.busreservation.service.BusService;

import java.util.List;
import java.util.Scanner;

/**
 * Bus Reservation System - Console Application
 * Demonstrates clean OOP design, validation, and end-to-end feature ownership.
 */
public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static final BusService busService = new BusService();
    private static final BookingService bookingService = new BookingService(busService);

    public static void main(String[] args) {
        printWelcome();

        boolean running = true;
        while (running) {
            printMenu();
            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1" -> searchAndDisplayBuses();
                case "2" -> viewSeatMap();
                case "3" -> bookTicket();
                case "4" -> cancelTicket();
                case "5" -> viewMyBookings();
                case "6" -> {
                    System.out.println("\nThank you for using Bus Reservation System. Goodbye!");
                    running = false;
                }
                default -> System.out.println("\nInvalid option. Please choose 1-6.");
            }
        }
        scanner.close();
    }

    private static void printWelcome() {
        System.out.println("=================================================");
        System.out.println("       BUS RESERVATION SYSTEM");
        System.out.println("   Clean Java - OOP - End-to-End Ownership");
        System.out.println("=================================================");
    }

    private static void printMenu() {
        System.out.println("\n--------------- MAIN MENU ---------------");
        System.out.println("1. Search Buses");
        System.out.println("2. View Seat Map");
        System.out.println("3. Book Ticket");
        System.out.println("4. Cancel Ticket");
        System.out.println("5. View All Bookings");
        System.out.println("6. Exit");
        System.out.print("Enter your choice: ");
    }

    private static void searchAndDisplayBuses() {
        System.out.print("\nEnter From city: ");
        String from = scanner.nextLine();
        System.out.print("Enter To city: ");
        String to = scanner.nextLine();

        List<Bus> results = busService.searchBuses(from, to);

        if (results.isEmpty()) {
            System.out.println("\nNo buses found for " + from + " -> " + to);
            return;
        }

        System.out.println("\nAvailable Buses:");
        System.out.println("Bus No     | From         -> To           | Time     | Fare     | Seats");
        System.out.println("-----------|--------------------------------|----------|----------|-------------");
        for (Bus bus : results) {
            System.out.println(bus);
        }
    }

    private static void viewSeatMap() {
        System.out.print("\nEnter Bus Number: ");
        String busNumber = scanner.nextLine();

        busService.findBusByNumber(busNumber).ifPresentOrElse(
                busService::displaySeatMap,
                () -> System.out.println("Bus not found.")
        );
    }

    private static void bookTicket() {
        System.out.print("\nEnter Bus Number: ");
        String busNumber = scanner.nextLine();

        System.out.print("Enter Seat Number: ");
        int seatNumber;
        try {
            seatNumber = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("Invalid seat number. Please enter a number.");
            return;
        }

        System.out.print("Enter Passenger Name: ");
        String name = scanner.nextLine();

        try {
            Booking booking = bookingService.bookSeat(busNumber, seatNumber, name);
            System.out.println("\n[OK] Booking Successful!");
            System.out.println(booking);
        } catch (IllegalArgumentException | IllegalStateException e) {
            System.out.println("\n[X] Booking Failed: " + e.getMessage());
        }
    }

    private static void cancelTicket() {
        System.out.print("\nEnter Booking ID: ");
        String bookingId = scanner.nextLine();

        boolean cancelled = bookingService.cancelBooking(bookingId);
        if (cancelled) {
            System.out.println("[OK] Booking " + bookingId + " cancelled successfully. Seat is now available.");
        } else {
            System.out.println("[X] Booking ID not found.");
        }
    }

    private static void viewMyBookings() {
        List<Booking> all = bookingService.getAllBookings();
        if (all.isEmpty()) {
            System.out.println("\nNo bookings found.");
            return;
        }
        System.out.println("\nAll Bookings:");
        for (Booking b : all) {
            System.out.println(b);
        }
    }
}
