package com.busreservation.model;

/**
 * Represents a single seat in a bus.
 */
public class Seat {
    private final int seatNumber;
    private boolean booked;
    private String passengerName;

    public Seat(int seatNumber) {
        this.seatNumber = seatNumber;
        this.booked = false;
        this.passengerName = null;
    }

    public int getSeatNumber() {
        return seatNumber;
    }

    public boolean isBooked() {
        return booked;
    }

    public String getPassengerName() {
        return passengerName;
    }

    public void book(String passengerName) {
        if (this.booked) {
            throw new IllegalStateException("Seat " + seatNumber + " is already booked.");
        }
        this.booked = true;
        this.passengerName = passengerName;
    }

    public void cancel() {
        this.booked = false;
        this.passengerName = null;
    }

    @Override
    public String toString() {
        if (booked) {
            return String.format("Seat %-2d [BOOKED - %s]", seatNumber, passengerName);
        }
        return String.format("Seat %-2d [AVAILABLE]", seatNumber);
    }
}
