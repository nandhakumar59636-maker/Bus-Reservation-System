package com.busreservation.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a single bus with seats and route information.
 */
public class Bus {
    private final String busNumber;
    private final String from;
    private final String to;
    private final String departureTime;
    private final double fare;
    private final int totalSeats;
    private final List<Seat> seats;

    public Bus(String busNumber, String from, String to, String departureTime, double fare, int totalSeats) {
        this.busNumber = busNumber;
        this.from = from;
        this.to = to;
        this.departureTime = departureTime;
        this.fare = fare;
        this.totalSeats = totalSeats;
        this.seats = new ArrayList<>();

        // Initialize seats (1 to totalSeats)
        for (int i = 1; i <= totalSeats; i++) {
            seats.add(new Seat(i));
        }
    }

    public String getBusNumber() {
        return busNumber;
    }

    public String getFrom() {
        return from;
    }

    public String getTo() {
        return to;
    }

    public String getDepartureTime() {
        return departureTime;
    }

    public double getFare() {
        return fare;
    }

    public int getTotalSeats() {
        return totalSeats;
    }

    public List<Seat> getSeats() {
        return seats;
    }

    public int getAvailableSeatCount() {
        int count = 0;
        for (Seat seat : seats) {
            if (!seat.isBooked()) {
                count++;
            }
        }
        return count;
    }

    public Seat getSeat(int seatNumber) {
        if (seatNumber < 1 || seatNumber > totalSeats) {
            return null;
        }
        return seats.get(seatNumber - 1);
    }

    @Override
    public String toString() {
        return String.format("%-10s | %-12s -> %-12s | %-8s | ₹%-7.0f | Available: %d/%d",
                busNumber, from, to, departureTime, fare, getAvailableSeatCount(), totalSeats);
    }
}
