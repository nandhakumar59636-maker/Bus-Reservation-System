package com.busreservation.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

/**
 * Represents a confirmed booking.
 */
public class Booking {
    private final String bookingId;
    private final String passengerName;
    private final String busNumber;
    private final int seatNumber;
    private final double fare;
    private final String bookingTime;

    public Booking(String passengerName, String busNumber, int seatNumber, double fare) {
        this.bookingId = UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        this.passengerName = passengerName;
        this.busNumber = busNumber;
        this.seatNumber = seatNumber;
        this.fare = fare;
        this.bookingTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm"));
    }

    public String getBookingId() {
        return bookingId;
    }

    public String getPassengerName() {
        return passengerName;
    }

    public String getBusNumber() {
        return busNumber;
    }

    public int getSeatNumber() {
        return seatNumber;
    }

    public double getFare() {
        return fare;
    }

    public String getBookingTime() {
        return bookingTime;
    }

    @Override
    public String toString() {
        return String.format("""
                --------------------------------
                  Booking ID   : %s
                  Passenger    : %s
                  Bus Number   : %s
                  Seat Number  : %d
                  Fare         : ₹%.0f
                  Booked At    : %s
                --------------------------------""",
                bookingId, passengerName, busNumber, seatNumber, fare, bookingTime);
    }
}
