package com.busreservation.service;

import com.busreservation.model.Bus;
import com.busreservation.model.Seat;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Handles bus-related operations: search, availability, etc.
 */
public class BusService {
    private final List<Bus> buses;

    public BusService() {
        this.buses = new ArrayList<>();
        seedBuses();
    }

    private void seedBuses() {
        buses.add(new Bus("TN01A1234", "Chennai", "Madurai", "06:00", 450.0, 40));
        buses.add(new Bus("TN01B5678", "Chennai", "Madurai", "14:30", 480.0, 40));
        buses.add(new Bus("TN02C9012", "Chennai", "Coimbatore", "07:15", 550.0, 36));
        buses.add(new Bus("TN03D3456", "Madurai", "Chennai", "08:00", 450.0, 40));
        buses.add(new Bus("TN04E7890", "Coimbatore", "Chennai", "21:00", 600.0, 36));
        buses.add(new Bus("TN05F2468", "Madurai", "Bangalore", "22:30", 700.0, 40));
    }

    public List<Bus> getAllBuses() {
        return new ArrayList<>(buses);
    }

    public List<Bus> searchBuses(String from, String to) {
        return buses.stream()
                .filter(bus -> bus.getFrom().equalsIgnoreCase(from.trim())
                        && bus.getTo().equalsIgnoreCase(to.trim()))
                .collect(Collectors.toList());
    }

    public Optional<Bus> findBusByNumber(String busNumber) {
        return buses.stream()
                .filter(bus -> bus.getBusNumber().equalsIgnoreCase(busNumber.trim()))
                .findFirst();
    }

    public void displaySeatMap(Bus bus) {
        System.out.println("\nSeat Map for Bus " + bus.getBusNumber() + ":");
        System.out.println("----------------------------------------");
        List<Seat> seats = bus.getSeats();
        for (int i = 0; i < seats.size(); i++) {
            Seat seat = seats.get(i);
            String status = seat.isBooked() ? "[X]" : "[ ]";
            System.out.printf("%2d%s  ", seat.getSeatNumber(), status);
            if ((i + 1) % 4 == 0) {
                System.out.println();
            }
        }
        System.out.println("\n----------------------------------------");
        System.out.println("[ ] = Available    [X] = Booked");
        System.out.println("Available seats: " + bus.getAvailableSeatCount() + "/" + bus.getTotalSeats());
    }
}
