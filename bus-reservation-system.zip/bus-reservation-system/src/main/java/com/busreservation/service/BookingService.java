package com.busreservation.service;

import com.busreservation.model.Booking;
import com.busreservation.model.Bus;
import com.busreservation.model.Seat;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Handles booking and cancellation logic.
 */
public class BookingService {
    private final BusService busService;
    private final List<Booking> bookings;

    public BookingService(BusService busService) {
        this.busService = busService;
        this.bookings = new ArrayList<>();
    }

    /**
     * Books a seat after performing all validations.
     */
    public Booking bookSeat(String busNumber, int seatNumber, String passengerName) {
        // Validation 1: Passenger name
        if (passengerName == null || passengerName.trim().isEmpty()) {
            throw new IllegalArgumentException("Passenger name cannot be empty.");
        }

        // Validation 2: Bus exists
        Optional<Bus> busOpt = busService.findBusByNumber(busNumber);
        if (busOpt.isEmpty()) {
            throw new IllegalArgumentException("Bus number " + busNumber + " not found.");
        }
        Bus bus = busOpt.get();

        // Validation 3: Seat number valid
        Seat seat = bus.getSeat(seatNumber);
        if (seat == null) {
            throw new IllegalArgumentException("Invalid seat number. Please choose between 1 and " + bus.getTotalSeats());
        }

        // Validation 4: Seat already booked
        if (seat.isBooked()) {
            throw new IllegalStateException("Seat " + seatNumber + " is already booked by " + seat.getPassengerName());
        }

        // All good → book the seat
        seat.book(passengerName.trim());
        Booking booking = new Booking(passengerName.trim(), bus.getBusNumber(), seatNumber, bus.getFare());
        bookings.add(booking);
        return booking;
    }

    /**
     * Cancels a booking by booking ID.
     */
    public boolean cancelBooking(String bookingId) {
        Optional<Booking> bookingOpt = bookings.stream()
                .filter(b -> b.getBookingId().equalsIgnoreCase(bookingId.trim()))
                .findFirst();

        if (bookingOpt.isEmpty()) {
            return false;
        }

        Booking booking = bookingOpt.get();
        Optional<Bus> busOpt = busService.findBusByNumber(booking.getBusNumber());
        if (busOpt.isPresent()) {
            Seat seat = busOpt.get().getSeat(booking.getSeatNumber());
            if (seat != null) {
                seat.cancel();
            }
        }
        bookings.remove(booking);
        return true;
    }

    public List<Booking> getAllBookings() {
        return new ArrayList<>(bookings);
    }

    public Optional<Booking> findBookingById(String bookingId) {
        return bookings.stream()
                .filter(b -> b.getBookingId().equalsIgnoreCase(bookingId.trim()))
                .findFirst();
    }
}
